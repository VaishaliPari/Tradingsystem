
public class Exchange {
	
	public double fill(double SliceQty,double availableQty){
		return availableQty-SliceQty;	
	}

}
